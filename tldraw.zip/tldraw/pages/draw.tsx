import { Card } from "@mui/material";
import { Typography } from "@mui/material/styles/createTypography";

const Draw = () => {
  return (
    <Card>
      
    </Card>
  )
};

export default Draw;
