import Wrapper from "../layout/Wrapper/Wrapper";
import '@tldraw/tldraw/tldraw.css';

import type { AppProps } from "next/app";

export default function App({ Component, pageProps }: AppProps) {
  return (
    <Wrapper>
      <Component {...pageProps} />
    </Wrapper>
  );
}
