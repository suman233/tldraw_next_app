export const validationText={
    error:{
       enter_firstName:"Please Enter Your First Name",
       enter_lastName:"Please Enter Your Last Name",
       enter_email:"Please Enter Your Email",
       enter_password:"Please Enter Password",
       enter_image:"Please Enter Your Image"
    }
}