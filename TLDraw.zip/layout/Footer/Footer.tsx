import { Divider, Typography } from "@mui/material";
import React from "react";

const Footer = () => {
  return (
    <div>
        <Divider sx={{my:2}} />
      <Typography>Footer</Typography>
    </div>
  );
};

export default Footer;
